#ifdef min
#undef min
#endif

#ifdef max
#undef max
#endif