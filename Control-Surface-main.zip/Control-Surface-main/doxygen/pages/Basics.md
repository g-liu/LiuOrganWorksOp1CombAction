# Basics {#md_pages_Basics}
This content was moved to @ref midi_md-midi-addresses "MIDI Tutorial: MIDI addresses".