#include "USBMIDI_Teensy3.hpp"
BEGIN_CS_NAMESPACE
using Teensy4_USBDeviceMIDIBackend = Teensy3_USBDeviceMIDIBackend;
END_CS_NAMESPACE
